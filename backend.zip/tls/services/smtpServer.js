const { SMTPServer } = require("smtp-server");
const net = require("net");
const ReceivedEmail = require("../models/ReceivedEmail");

// Start SMTP Server
const startSmtpServer = () => {
  const smtpServer = new SMTPServer({
    onData(stream, session, callback) {
      let emailContent = "";
      stream.on("data", (chunk) => {
        emailContent += chunk.toString();
      });
      stream.on("end", () => {
        const emailData = parseEmailToJson(emailContent);
        const receivedEmail = new ReceivedEmail({
          from: emailData["From"],
          to: emailData["To"],
          cc: emailData["Cc"],
          bcc: emailData["Bcc"],
          subject: emailData["Subject"],
          message: emailData.body
        });

        receivedEmail.save()
          .then(() => {
            console.log("Email saved to database:", receivedEmail);
            callback();
          })
          .catch(err => {
            console.error("Error saving received email:", err);
            callback();
          });
      });
    },
    authOptional: true,
    secure: false,
  });

  smtpServer.listen(587, "localhost", () => {
    console.log("SMTP Server listening on localhost:587");
  });
};

// Parse email content to JSON format
const parseEmailToJson = (emailContent) => {
  const lines = emailContent.split("\r\n");
  const emailData = {};
  let isBody = false;
  let body = "";

  for (const line of lines) {
    if (line.trim() === "") {
      isBody = true;
      continue;
    }

    if (isBody) {
      body += line + "\n";
    } else {
      const [key, ...value] = line.split(": ");
      if (key) {
        emailData[key] = value.join(": ");
      }
    }
  }

  emailData.body = body.trim();
  return emailData;
};

// Send email function with logging at each state
const sendMail = ({ from, to, subject, message, attachment, cc, bcc }) => {
  const mxHost = "localhost";
  return new Promise((resolve, reject) => {
    const socket = net.connect(587, mxHost, () => {
      console.log(`Connected to ${mxHost} over TCP`);
    });

    let state = 0;

    socket.on("data", (data) => {
      const response = data.toString();
      console.log("Server response:", response); // Log each server response

      if (state === 0 && response.startsWith("220")) {
        console.log("Sending EHLO...");
        socket.write(`EHLO ${from.split("@")[1]}\r\n`);
        state++;
      } else if (state === 1 && response.startsWith("250")) {
        console.log("Sending MAIL FROM...");
        socket.write(`MAIL FROM:<${from}>\r\n`);
        state++;
      } else if (state === 2 && response.startsWith("250")) {
        console.log("Sending RCPT TO...");
        socket.write(`RCPT TO:<${to}>\r\n`);
        state++;
      } else if (state === 3 && response.startsWith("250")) {
        console.log("Sending DATA...");
        socket.write("DATA\r\n");
        state++;
      } else if (state === 4 && response.startsWith("354")) {
        console.log("Sending email data...");
        const emailData = `From: ${from}\r\nTo: ${to}\r\nSubject: ${subject}\r\n\r\n${message}\r\n.\r\n`;
        socket.write(emailData);
        state++;
      } else if (state === 5 && response.startsWith("250")) {
        console.log("Email sent successfully.");
        resolve();
        socket.end();
      } else if (response.startsWith("5")) {
        console.error("Error sending email:", response);
        reject(new Error(response));
        socket.end();
      }
    });

    socket.on("error", (error) => {
      console.error("Socket error:", error);
      reject(error);
    });

    socket.on("end", () => {
      console.log("Connection ended.");
    });
  });
};

module.exports = { startSmtpServer, sendMail };
