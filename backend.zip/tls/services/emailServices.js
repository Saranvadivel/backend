const ReceivedEmail = require("../models/ReceivedEmail");
const SentEmail = require("../models/SentEmail");
const { sendMail } = require("./smtpServer");
const jwt = require("jsonwebtoken");

const sendEmail = async (req, res) => {
  const { to, cc, bcc, subject, message } = req.body;
  const attachment = req.file ? `http://localhost:3000/uploads/${req.file.filename}` : null;

  console.log("Send Email Request Data:", { to, cc, bcc, subject, message, attachment });

  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).send("Access denied. No token provided.");
  }

  let userEmail;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    userEmail = decoded.email;
  } catch (err) {
    return res.status(400).send("Invalid token.");
  }

  const recipients = to.split(",").map(email => email.trim());
  const ccRecipients = cc ? cc.split(",").map(email => email.trim()) : [];
  const bccRecipients = bcc ? bcc.split(",").map(email => email.trim()) : [];
  const allRecipients = [...recipients, ...ccRecipients, ...bccRecipients];

  console.log("All Recipients:", allRecipients);

  const sendPromises = allRecipients.map(recipient => 
    sendMail({ from: userEmail, to: recipient, subject, message, attachment, cc, bcc })
      .then(() => {
        const sentEmail = new SentEmail({ from: userEmail, to: recipient, cc, bcc, subject, message, attachment });
        console.log("Saving sent email record:", sentEmail);
        return sentEmail.save();
      })
  );

  try {
    await Promise.all(sendPromises);
    console.log("Emails sent successfully!");
    res.status(200).send("Emails sent successfully");
  } catch (err) {
    console.error("Failed to send emails:", err);
    res.status(500).send("Failed to send emails: " + err.message);
  }
};

const getEmails = async (req, res) => {
  try {
    const sentEmails = await SentEmail.find();
    const receivedEmails = await ReceivedEmail.find();
    console.log("Fetched Sent Emails:", sentEmails);
    console.log("Fetched Received Emails:", receivedEmails);
    res.status(200).send([...sentEmails, ...receivedEmails]);
  } catch (err) {
    console.error("Failed to fetch emails:", err);
    res.status(500).send("Failed to fetch emails: " + err.message);
  }
};

const getReceivedEmails = async (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).send("Access denied. No token provided.");
  }

  let userEmail;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    userEmail = decoded.email;
  } catch (err) {
    return res.status(400).send("Invalid token.");
  }

  try {
    const receivedEmails = await ReceivedEmail.aggregate([
      { $match: { to: userEmail } },
      {
        $project: {
          _id: 1,
          from: 1,
          to: 1,
          cc: 1,
          bcc: 1,
          subject: 1,
          message: 1,
          receivedAt: 1
        }
      },
      { $sort: { receivedAt: -1 } }
    ]);
    console.log("Received Emails for User:", userEmail);
    console.log(receivedEmails);
    res.status(200).send(receivedEmails);
  } catch (err) {
    console.error("Failed to fetch received emails:", err);
    res.status(500).send("Failed to fetch received emails: " + err.message);
  }
};

const getSentEmails = async (req, res) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).send("Access denied. No token provided.");
  }

  let userEmail;
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    userEmail = decoded.email;
  } catch (err) {
    return res.status(400).send("Invalid token.");
  }

  try {
    const sentEmails = await SentEmail.find({ from: userEmail });
    console.log("Sent Emails for User:", userEmail);
    console.log(sentEmails);
    res.status(200).send(sentEmails);
  } catch (err) {
    console.error("Failed to fetch sent emails:", err);
    res.status(500).send("Failed to fetch sent emails: " + err.message);
  }
};

module.exports = { sendEmail, getEmails, getReceivedEmails, getSentEmails };
