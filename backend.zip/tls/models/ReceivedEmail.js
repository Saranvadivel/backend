const mongoose = require("mongoose");

const receivedEmailSchema = new mongoose.Schema({
  from: String,
  to: String,
  cc: String,
  bcc: String,
  subject: String,
  message: String,
  receivedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("ReceivedEmail", receivedEmailSchema);
