const mongoose = require("mongoose");

const sentEmailSchema = new mongoose.Schema({
  from: String,
  to: String,
  cc: String,
  bcc: String,
  subject: String,
  message: String,
  attachment: String,
  sentAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("SentEmail", sentEmailSchema);
